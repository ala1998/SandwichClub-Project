package com.udacity.sandwichclub.utils;

import android.widget.Toast;

import com.udacity.sandwichclub.MainActivity;
import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {
 try{
     JSONObject jsnObj=new JSONObject(json);
     JSONObject name=jsnObj.getJSONObject("name");
    // JSONObject mainName=name.getJSONObject("mainName");
     JSONArray alsoKnown=name.getJSONArray("alsoKnownAs");
    // JSONObject placeOfOrigin=jsnObj.getJSONObject("placeOfOrigin");
     //JSONObject description=jsnObj.getJSONObject("description");
     //JSONObject image =jsnObj.getJSONObject("image");
     JSONArray ingredients=jsnObj.getJSONArray("ingredients");

     String mName=name.getString("mainName");
     List<String> knownList=new ArrayList<String>();

     for(int i=0;i<alsoKnown.length();i++)
         knownList.add(alsoKnown.getString(i));

     String place=jsnObj.getString("placeOfOrigin");
     String desc=jsnObj.getString("description");
     String img=jsnObj.getString("image");
     List<String> ingredList=new ArrayList<String>();

     for(int i=0;i<ingredients.length();i++)
         ingredList.add(ingredients.getString(i));

     Sandwich sandwich=new Sandwich();
     sandwich.setMainName(mName);
     sandwich.setAlsoKnownAs(knownList);
     sandwich.setPlaceOfOrigin(place);
     sandwich.setDescription(desc);
     sandwich.setImage(img);
     sandwich.setIngredients(ingredList);

     return sandwich;
 }
        catch (JSONException e)
        {
            e.printStackTrace();
        return null;
        }
      /*  {
            "name":{
                "mainName":"Bosna",
                "alsoKnownAs":[
                        "Bosner"
            ]
        },
            "placeOfOrigin":"Austria",
                "description":"Bosna is a spicy Austrian fast food dish, said to have originated in either Salzburg or Linz.
            It is now popular all over western Austria and southern
            Bavaria.",
                "image":"https://upload.wikimedia.org/wikipedia/commons/c/ca/Bosna_mit_2_Bratw%C3%BCrsten.jpg",
            "ingredients":[
                    "White bread","Bratwurst","Onions","Tomato ketchup","Mustard","Curry powder"
            ]
        }
*/
    }
}
